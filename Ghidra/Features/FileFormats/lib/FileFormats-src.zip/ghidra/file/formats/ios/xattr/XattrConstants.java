/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ghidra.file.formats.ios.xattr;

public final class XattrConstants {

	public final static String      RESOURCE_XATTR_NAME  =  "com.apple.ResourceFork";
	public final static String       DECMPFS_XATTR_NAME  =  "com.apple.decmpfs";
	public final static String KAUTH_FILESEC_XATTR_NAME  =  "com.apple.system.Security";
	public final static String      KAUTH_SCOPE_PROCESS  =  "com.apple.kauth.process";
	
}
